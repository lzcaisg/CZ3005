CZ3005-Lab2-Assignment1
CAI Lingzhi, U1622184H, 9/Nov/2018

There are 5 files in the directory:
- CAI_Lingzhi_U1622184H-CZ3005 Lab-2.pdf is the lab report;
- lab2-ass1-athlete.pl is the program. To start the program, you can key in "start."
- Data_Preprocessing.py is the data preprocessing script written in python. It generates the Prolog Facts as the knowledge base.
- Olympics.csv is the original information retrieved from Wikipedia.
- Readme.txt is this file.

Thank you for your time.